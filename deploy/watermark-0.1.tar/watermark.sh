#!/usr/bin/env sh

python watermark.py $@