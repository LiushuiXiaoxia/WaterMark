#!/bin/sh

python watermark.py $@